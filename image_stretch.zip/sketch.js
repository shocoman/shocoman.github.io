let img;

function preload() {

  img = loadImage('image.bmp');
}

function setup() {
  createCanvas(512, 1024);



  noLoop();
}

function draw() {
  background(220);
  //image(img, 0, 0, img.width, img.height);

  //   img.loadPixels();
  //   print(img.pixels.length);
  //   for (let j = 0; j < img.height * 3; j++) {
  //     for (let i = 0; i < img.width * 3; i += 4) {
  //       //print(0 + i * img.width, pixels[0 + i * img.width]);
  //       //img.pixels[i + j * img.width] = 0;
  //       //img.pixels[i+1 + j * img.width] = 0;
  //       //img.pixels[i+2 + j * img.width] = 0;
  //       //img.pixels[i+3 + j * img.width] = 0;

  //       stroke(img.pixels[i + j * img.width],
  //              img.pixels[i+1 + j * img.width],
  //              img.pixels[i+2 + j * img.width],
  //              img.pixels[i+3 + j * img.width]);

  //       point(i * width/img.width/4,j * height/img.height/4);
  //     }
  //   }
  //   img.updatePixels();

  img.loadPixels();


  let ncol = 0;
  while (ncol < 32) {

    drawColumn(img, ncol, 31);
    ncol++;
  }
  
  
 // drawColumn(img, 20, 256);
  
}


function drawColumn(img, n, h) {

  let ncol = n * 4;
  for (let row = 0; row < h; row += 1) {
    row = floor(row);
    
    let nrow = floor(row * (img.width * 4) * img.width/h);
    //print(nrow);
    stroke(img.pixels[ncol + nrow],
      img.pixels[ncol + 1 + nrow],
      img.pixels[ncol + 2 + nrow],
      img.pixels[ncol + 3 + nrow]);

    point(n, row);
  }

}